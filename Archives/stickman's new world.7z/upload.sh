git clone https://github.com/michael78912/michael78912.github.io
cd michael78912.github.io
ls
git init
python3 ../this.py
git add *
git commit -m "added to dev log"
git push origin master
cd ..
#rm michael78912.github.io -r
